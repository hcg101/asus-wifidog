/* ossl_typ.h for openssl */

