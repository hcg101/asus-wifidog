/* bio.h for openssl */


#ifndef CYASSL_BIO_H_
#define CYASSL_BIO_H_

#include <cyassl/openssl/ssl.h>


#ifdef __cplusplus
    extern "C" {
#endif




#ifdef __cplusplus
    }  /* extern "C" */ 
#endif


#endif /* CYASSL_BIO_H_ */

